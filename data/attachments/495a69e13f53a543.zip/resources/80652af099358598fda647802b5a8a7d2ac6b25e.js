importScripts(
  'https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js'
);
importScripts(
  'https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js'
);

const firebaseConfig = {
  apiKey: 'AIzaSyC5cRqdDtLWwJpz7WY1Ekpx7rbawbG1CA8',
  authDomain: 'intelehealth-3-0.firebaseapp.com',
  projectId: 'intelehealth-3-0',
  storageBucket: 'intelehealth-3-0.firebasestorage.app',
  messagingSenderId: '781318396284',
  appId: '1:781318396284:web:69d37af4daa956a3df6cf9',
};

console.warn(
  'Firebase config loaded: apiKey=',
  firebaseConfig.apiKey ? firebaseConfig.apiKey.slice(0, 8) + '...' : 'MISSING',
  'projectId=',
  firebaseConfig.projectId || 'MISSING'
);

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

// Fires for DATA-ONLY payloads when app is backgrounded
// If server sends { notification: {...} }, FCM auto-displays — this won't fire
messaging.onBackgroundMessage(payload => {
  console.warn('onBackgroundMessage received:', JSON.stringify(payload));
  const data = payload.data || {};
  const notif = payload.notification || {};

  const title = data.title || notif.title || 'New Notification';
  const body = data.body || notif.body || '';
  const icon = data.icon || notif.icon || '/favicon.ico';
  const tag = data.tag || notif.tag || 'default-tag';

  // Forward push data to all open app tabs for toast/badge update
  self.clients
    .matchAll({ type: 'window', includeUncontrolled: true })
    .then(clientList => {
      clientList.forEach(client => {
        client.postMessage({ type: 'PUSH_RECEIVED', data });
      });
    });

  return self.registration.showNotification(title, {
    body,
    icon,
    badge: '/favicon.ico',
    tag,
    renotify: true,
    data: { ...data, click_action: data.click_action || notif.click_action },
  });
});

// Notification click
self.addEventListener('notificationclick', event => {
  event.notification.close();

  const clickAction = event.notification.data?.click_action;

  event.waitUntil(
    clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then(clientList => {
        // If target URL already open, focus it
        if (clickAction) {
          for (const client of clientList) {
            if (client.url === clickAction && 'focus' in client) {
              return client.focus();
            }
          }
          return clients.openWindow(clickAction);
        }

        // Otherwise focus any existing window
        for (const client of clientList) {
          if ('focus' in client) return client.focus();
        }
        return clients.openWindow('/');
      })
  );
});

// Re-subscribe if push subscription expires
self.addEventListener('pushsubscriptionchange', event => {
  event.waitUntil(
    self.registration.pushManager
      .subscribe({ userVisibleOnly: true })
      .then(() => {
        // Token will be re-fetched by the app on next load
      })
      .catch(err => console.error('[SW] Resubscribe failed:', err))
  );
});

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});
